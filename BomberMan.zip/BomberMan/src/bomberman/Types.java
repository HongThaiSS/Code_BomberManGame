
package bomberman;


public class Types {
   

    
    //Các phần tử cơ bản
    public enum BlockType{
        BREAKABLE, 
        UNBREKABLE,
        EMPTY,
        BOMB,
        FIRE,
        POWER_UP,
        PLAYER,
        ENEMY 
    };
    
    
    //các loại items tăng sức mạnh
    public enum PowerUps{

        SPEED_UP,               //tăng tốc độ
        RANGE_UP,               //vùng cháy của bom rộng hơn
        BOMBS_UP                //co thể đặt nhiều bom cùng lúc
    };
    
    public enum Move{
        
        UP,
        LEFT,
        RIGHT,
        DOWN,
        STOP,
        PLACE_BOMB
    };
}