
package bomberman;

import java.awt.Image;
import java.awt.Rectangle;
import java.io.File;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.sound.sampled.*;

public class Bomb extends MapOfBlocks implements Runnable {

    boolean justPlanted = true;
    static CopyOnWriteArrayList<Bomb> allBombs = new CopyOnWriteArrayList<Bomb>();
    static int size = Images.BOMBSIZE;
    static int vibrateTimer = 200;
    static int explosionTimer = 10;

    Thread vibrate;
    Thread explode;

    public Bomb(Position _position) {

        super(Types.BlockType.BOMB, _position);
        vibrate = new Thread(new Runnable() {
            public void run() {
                int timer = 0;
                while (timer < explosionTimer) {
                    try {
                        Thread.sleep(vibrateTimer);
                    } catch (InterruptedException e) {
                        System.out.println("interrupted");
                    }
                    timer++;
                    pulsate();
                }
               //Sounds.getInstance().Explosion();
                explode();
            }
        });
        vibrate.start();
    }

    public Rectangle getBounds() {
        return new Rectangle(getX(), getY(), size, size);
    }

    @Override
    public void run() {
        System.out.println("BOMB THREAD STARTED");
    }

    public void explode() {

        BomberMan.players.get(0).bombs.remove(0);
        startFire();
    }

    public void pulsate() {
        if (getImage().equals(Images.BOMB_BIG)) {
            setX(getX() + 5);
            setY(getY() + 5);
            setImage(Images.BOMB_SMALL);
        } else {
            setX(getX() - 5);
            setY(getY() - 5);
            setImage(Images.BOMB_BIG);
        }
    }

    public void startFire() {
       
        Fire.startFire(getPosition());
    }
}