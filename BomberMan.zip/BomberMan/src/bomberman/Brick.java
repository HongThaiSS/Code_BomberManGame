
package bomberman;

import java.awt.Image;



public class Brick extends MapOfBlocks {
    
    public Brick(Types.BlockType _blockType, Position _position){
        
        super( _blockType,_position);
    }
    
}