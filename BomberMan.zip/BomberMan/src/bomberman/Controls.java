/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import java.awt.event.KeyEvent;


public interface Controls {

    int up = KeyEvent.VK_UP;
    int down = KeyEvent.VK_DOWN;
    int left = KeyEvent.VK_LEFT;
    int right = KeyEvent.VK_RIGHT;
    int bomb= KeyEvent.VK_SPACE ;
}