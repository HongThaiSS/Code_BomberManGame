/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import bomberman.Types.*;

public class MoveIt {

    public static void Move(Bomber player) {
        int x = player.getX();
        int y = player.getY();

        if(!player.isAlive()){
            return;
        }
        
        if (MoveDirect.isValidMove(player, player.direction)) {
            MoveExecutor.executeMove(player, player.direction);
        }
    }
}