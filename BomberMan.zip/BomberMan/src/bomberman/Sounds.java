/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bomberman;

import java.io.File;
import java.io.InputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

/**
 *
 * @author Genius
 */
public class Sounds {
    private Clip clip;
    public Sounds(String name){
        try {
            InputStream stream = this.getClass().getResourceAsStream("/sounds/" + name);
            AudioInputStream audio = AudioSystem.getAudioInputStream(stream);
            clip = AudioSystem.getClip();
            clip.open(audio);
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
    public void play(int loop){
        clip.setFramePosition(0);
        clip.loop(loop);
    }
    
    static Sounds sound;
    Clip bg=null;
    Clip explosion=null;

    public Sounds() {
        try {
//            AudioInputStream bgAudio = AudioSystem.getAudioInputStream(new File("sounds/Battle/"+".mid"));
//            bg = AudioSystem.getClip();
//            bg.open(bgAudio);
            AudioInputStream explosionAudio = AudioSystem.getAudioInputStream(new File("sounds/Explosion/"+".mp3"));
            explosion = AudioSystem.getClip();
            explosion.open(explosionAudio);
        } catch (Exception e) {
        }
    }

    public static Sounds getInstance() {
        if (sound == null) {
            sound = new Sounds();
        }
        return sound;
    }

    public void Explosion() {
        explosion.start();
        explosion.close();
    }

}